# Bigelow zipper twist extension

## Main exact result

The unreduced Burau representation satisfies

```text
rho(sigma_1 X_2) = -u rho(X_2)
rho((sigma_1 sigma_2)^3 X_3) = u^3 rho(X_3).
```

At `u=q^3`, it simultaneously satisfies the requested twist relations and
`X_4=0`, while `X_3` remains nonzero of rank one.

## Files

- `BIGELOW_ZIPPER_TWIST_EXTENSION.tex`: formal pre-submission manuscript.
- `BIGELOW_ZIPPER_TWIST_EXTENSION.pdf`: compiled manuscript.
- `verify_twist_extension.py`: exact symbolic replay.
- `twist-extension-verification.json`: replay output.
- `verify_twist_extension_modular.py`: independent pure-Python finite-field replay.
- `twist-extension-modular-verification.json`: finite-field replay output.
- `NOVELTY_AUDIT_TWIST_EXTENSION.md`: strict priority boundary.
- `COVER_EMAIL_TO_BIGELOW.md`: concise response draft.
- `SUBMISSION_CHECKLIST.md`: completed checks and remaining submission gates.
- `TEACHER_REQUEST_COMPLETION.md`: exact closure of Stephen's emailed request.
- `BIGELOW_TEACHER_REQUEST_COMPLETED.json`: machine-readable completion receipt.
- `BIGELOW_ZIPPER_TWIST_SUBMISSION_2026-09-03.zip`: source and verification package.
- `BIGELOW_ZIPPER_TWIST_SUBMISSION_2026-09-03.zip.sha256`: package checksum.

## Scope

The manuscript constructs a finite-dimensional joint Burau/BMW image with a
nonzero kernel over BMW. It does not claim that the universal quotient by the
two twist relations and `X_4=0` is itself finite-dimensional.
