# Novelty audit boundary for the zipper-twist extension

**Checked through:** 2026-09-02 UTC  
**Status:** `novelty_pending_independent_specialist_review`

## Exact result under review

For Bigelow's printed zipper relation scheme, the unreduced Burau image obeys

```text
rho(sigma_1 X_2) = -u rho(X_2)
rho((sigma_1 sigma_2)^3 X_3) = u^3 rho(X_3).
```

After `u=q^3`, it also has `rho(X_4)=0` while `rho(X_3)` remains nonzero.
The joint Burau/BMW image is a finite-dimensional braid-group algebra
surjecting onto `BMW_n(q,-q^3)` with nonzero kernel.

## Closest primary and near-primary records

1. Bigelow's 2005 preprint / 2006 article defines the printed `Z_n`, asks
   whether `X_3=0`, asks what extra relations make it finite-dimensional, and
   suggests first studying the quotient by `X_4=0`. It does not state the two
   Burau twist formulas above.
2. The 2004 BIRS workshop report says Bigelow had described diagrammatic
   finite-dimensional zipper algebras properly extending BMW. The report does
   not contain the underlying proof, full defining relations, or a Burau
   specialization. This creates a serious priority boundary: the present
   construction must be compared with Bigelow's unpublished 2004 work.
3. Bigelow's AMS abstract for May 4, 2025 proposes a large finite-dimensional
   algebra with a finite normal-form algorithm, in current work with Choomno
   Moos. The public abstract does not give its presentation or the twist
   scalars.
4. Cabanes--Marin, Marin, Marin--Wagner, and Marin's 2022 maximal-cubic-
   quotient paper study cubic Hecke quotients and finite-dimensional cubic
   braid-group algebras. The first twist relation in the present manuscript implies the cubic polynomial
   `(sigma_i-1)(sigma_i+q)(sigma_i+q^3)=0`, so these papers are mandatory
   comparison points. No inspected title or abstract identifies the specific
   zipper elements or the Burau twist specialization.

## Searches performed

- exact and mixed searches for `zipper algebra`, `Bigelow X_3 Z_n`, `Burau
  zipper twist`, `X_4=0`, and finite-dimensional BMW extensions;
- arXiv title/abstract queries;
- Crossref bibliographic queries;
- the current AMS meeting API record for Paper 48822;
- the BIRS 04w5526 workshop report;
- the primary Bigelow source and its bibliography.

The searches found no published source stating the exact pair of Burau twist
formulas or the `u=q^3` specialization. This is not proof of originality.

## Required before an originality claim

1. Stephen Bigelow and Choomno Moos should compare the theorem with their
   unpublished/current zipper presentation.
2. A braid/BMW specialist independent of the authors should search
   MathSciNet, zbMATH, and notation-equivalent cubic quotient literature.
3. The exact relation convention and coefficient parameters intended in the
   email should be confirmed by Bigelow.
4. The manuscript should remain labelled as an independent calculation with
   novelty pending until those checks are complete.

## Safe public wording

> We give an explicit Burau calculation answering the communicated twist-
> compatibility question for the printed 2005 relation scheme. Worldwide
> priority and comparison with unpublished zipper presentations remain open.
