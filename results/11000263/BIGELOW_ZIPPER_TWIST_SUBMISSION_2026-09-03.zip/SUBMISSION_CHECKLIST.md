# Submission checklist

## Completed

- [x] Uniform proof of both twist eigenrelations.
- [x] Exact specialization `u=q^3` with `X_4=0` and `X_3!=0`.
- [x] Finite-dimensional joint Burau/BMW quotient with nonzero BMW kernel.
- [x] Symbolic replay for orders 4 through 8.
- [x] Independent pure-Python finite-field replay.
- [x] AMS-style five-page manuscript compiled without LaTeX warnings.
- [x] Strict novelty boundary and closest-prior-work section.
- [x] Draft response email to Stephen Bigelow.
- [x] Author names and email signature aligned with Stephen's address to
      `Zimo and Qiugu`.
- [x] Fresh symbolic, independent finite-field, and reproducible PDF rebuild
      completed on 2026-09-03.

## Required before external journal submission

- [ ] Insert full legal author names, affiliations, ORCID identifiers, and correspondence emails.
- [ ] Ask Stephen Bigelow to confirm the intended whole-word inverse, scalar parameters, and overlap with current work with Choomno Moos.
- [ ] Obtain an independent braid/BMW specialist review of the hand proof.
- [ ] Complete MathSciNet and zbMATH searches for notation-equivalent formulations.
- [ ] Select the journal and adapt the title page, bibliography style, and cover letter.

The current PDF is ready to send to Stephen as a formal pre-submission draft.
It should not yet be represented as a journal-submitted or novelty-certified paper.
